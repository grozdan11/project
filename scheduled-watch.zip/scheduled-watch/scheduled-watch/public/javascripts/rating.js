const socket = io();

document.querySelectorAll('.rating').forEach(el = {
  const movieId = el.dataset.id;
  const stars = [1, 2, 3, 4, 5].map(n = {
    const s = document.createElement('span');
    s.innerText = '★';
    s.style.cursor = 'pointer';
    s.style.fontSize = '20px';
    s.dataset.value = n;
    el.appendChild(s);
    return s;
  });

  stars.forEach(star = {
    star.addEventListener('click', () = {
      const rating = parseInt(star.dataset.value);
      socket.emit('rateMovie', { movieId, rating });
    });
  });

  socket.on('movieRated', ({ movieId id, rating }) = {
    if (movieId === id) {
      el.querySelectorAll('span').forEach((s, i) = {
        s.style.color = i  rating  'gold'  'gray';
      });
    }
  });
});
