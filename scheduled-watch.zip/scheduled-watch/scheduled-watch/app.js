require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const path = require('path');

const Movie = require('./models/Movie');
const User = require('./models/User');

const app = express();

// MongoDB connection
mongoose.connect(process.env.MONGODB_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true
})
.then(() => console.log('✅ Свързан с MongoDB Atlas'))
.catch(err => console.error('❌ Грешка при връзката с MongoDB:', err));

// Настройки
app.set('view engine', 'pug');
app.set('views', path.join(__dirname, 'views'));
app.use(express.static(path.join(__dirname, 'public')));
app.use(bodyParser.urlencoded({ extended: true }));

// 🔹 Начална страница
app.get('/', (req, res) => {
  res.render('index');
});

// 🔹 Регистрация
app.get('/register', (req, res) => {
  res.render('register');
});

app.post('/register', async (req, res) => {
  const { username, password } = req.body;
  try {
    const existing = await User.findOne({ username });
    if (existing) return res.send('Потребителското име вече съществува.');
    await User.create({ username, password });
    res.redirect('/login');
  } catch (err) {
    res.status(500).send('Грешка при регистрация');
  }
});

// 🔹 Вход (без сесии)
app.get('/login', (req, res) => {
  res.render('login');
});

app.post('/login', async (req, res) => {
  const { username, password } = req.body;
  try {
    const user = await User.findOne({ username, password });
    if (user) {
      res.redirect(`/dashboard?user=${user._id}`);
    } else {
      res.send('Грешно потребителско име или парола');
    }
  } catch (err) {
    res.status(500).send('Грешка при вход');
  }
});

// 🔹 Dashboard – показва всички филми/сериали
app.get('/dashboard', async (req, res) => {
  const userId = req.query.user;
  try {
    const movies = await Movie.find({ user: userId });
    res.render('dashboard', { movies, userId });
  } catch (err) {
    res.status(500).send('Грешка при зареждане на списъка');
  }
});

// 🔹 Добавяне на филм/сериал
app.get('/add', (req, res) => {
  res.render('add_movie', { userId: req.query.user });
});

app.post('/add', async (req, res) => {
  const { title, startDate, endDate, totalEpisodes, userId } = req.body;
  try {
    await Movie.create({
      title,
      startDate,
      endDate: endDate || null,
      totalEpisodes,
      currentEpisode: 0,
      user: userId
    });
    res.redirect(`/dashboard?user=${userId}`);
  } catch (err) {
    res.status(500).send('Грешка при добавяне');
  }
});

// 🔹 Изтриване на филм
app.get('/delete/:id', async (req, res) => {
  try {
    const movie = await Movie.findById(req.params.id);
    const userId = movie.user;
    await movie.deleteOne();
    res.redirect(`/dashboard?user=${userId}`);
  } catch (err) {
    res.status(500).send('Грешка при изтриване');
  }
});

// 🔹 Стартиране на сървъра
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`🚀 Сървърът работи на http://localhost:${PORT}`);
});
