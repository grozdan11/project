const express = require('express');
const router = express.Router();
const Movie = require('../models/Movie');

function authMiddleware(req, res, next) {
  if (!req.session.userId) return res.redirect('/login');
  next();
}

router.use(authMiddleware);

router.get('/', async (req, res) => {
  const genre = req.query.genre || '';
  const sort = req.query.sort || 'newest';
  let query = {};
  if (genre) query.genre = genre;

  let sortOption = { createdAt: -1 };
  if (sort === 'rating') sortOption = { rating: -1 };

  const genres = await Movie.distinct('genre');
  const movies = await Movie.find(query).sort(sortOption);

  res.render('movies/index', { movies, genres, selectedGenre: genre, selectedSort: sort });
});

// останалите рутове както преди...

module.exports = router;